# DNAsplot/__init__.py
from .DNAsplot import main
