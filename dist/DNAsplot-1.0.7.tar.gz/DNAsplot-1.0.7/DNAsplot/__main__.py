from .DNAsplot import main
main()
